import warnings
import numpy as np
from pandas.core.common import SettingWithCopyWarning
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)
from utlis import initialize_extra_features, feature_extract, train_test_split
from utlis import extract, data_labelling, type_of_data, extract_data
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score

# Load data from CSV file
data_type,data = type_of_data()  # choices=["dia", "sys", "eda", "res", "all"]
# Extract features from data
data = initialize_extra_features(data)
data = feature_extract(data)

# Labeling data
labeled_data = data_labelling(data)

# data extraction for that particular data type selected
Extracted_data = extract_data(data_type, labeled_data)

# Seperating data into input and target
X,y = extract(Extracted_data,data_type)

folds = 9 # Total 10 folds, one is kept for testing and 9 folds involved in training
spf = int(len(X)/(folds+1)) # Samples per fold
TrainData, TrainLabels, TestData, TestLabels = train_test_split(X,y,spf)

# Classifier selection
classifier = RandomForestClassifier(n_estimators = 100,max_depth=10, random_state=1)

# Initialization
avg_confusion_matrix = np.zeros((2, 2))
avg_accuracy = np.zeros(folds)
avg_precision = np.zeros(folds)
avg_recall = np.zeros(folds)

i = 0
for j in range(folds):
    train_data = TrainData[i:i+spf]
    train_labels = TrainLabels[i:i+spf]
    i = i+spf
    test_data,test_labels = TestData,TestLabels
    # Train classifier
    classifier.fit(train_data, train_labels)

    # Test classifier
    predicted_labels = classifier.predict(test_data)

    # Calculate performance metrics
    confusion = confusion_matrix(test_labels, predicted_labels)
    accuracy = accuracy_score(test_labels, predicted_labels)
    precision = precision_score(test_labels, predicted_labels)
    recall = recall_score(test_labels, predicted_labels)

    avg_confusion_matrix += confusion
    avg_accuracy[j]= accuracy
    avg_precision[j]= precision
    avg_recall[j]= recall

print("Confusion Matrix:")
print(avg_confusion_matrix/10)

"""Comment this line  to see the TestData Metrics on each fold of training over 9 folds
print('\n*** TestData Metrics on each fold of training over %d folds ***'%folds)
print("Accuracy : ", np.round(avg_accuracy,3))
print("Precision: ", np.round(avg_precision,3))
print("Recall   : ", np.round(avg_recall,3))
#"""

print('\n*** Mean metrics of TestData ***')
print("Mean Accuracy : ", np.mean(avg_accuracy, dtype=np.float16))
print("Mean Precision: ", np.mean(avg_precision, dtype=np.float16))
print("Mean Recall   : ", np.mean(avg_recall, dtype=np.float16))