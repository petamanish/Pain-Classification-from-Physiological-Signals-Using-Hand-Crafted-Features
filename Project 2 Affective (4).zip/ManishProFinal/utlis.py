import numpy as np
import pandas as pd
import argparse
import csv

def type_of_data():
    # Define command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_type', choices=["dia", "sys", "eda", "res", "all"], help="Type of data to run")
    parser.add_argument('--data_file', default="Project2Data.csv", help="Source Data File")
    args = parser.parse_args()
    df_index = ['Sub ID', 'Data Type', 'Class', 'Data']
    column_names = np.array(['col_' + str(i) for i in range(51304)])
    column_names[0:4] = df_index
    # Data file
    data = pd.read_csv(args.data_file, names=column_names)
    data = data.fillna(data.mean())

    # datatype selction based on argument passed
    if args.data_type == 'dia':
        data_type = 'BP Dia_mmHg'
    elif args.data_type == 'sys':
        data_type = 'LA Systolic BP_mmHg'
    elif args.data_type == 'eda':
        data_type = 'EDA_microsiemens'
    elif args.data_type == 'res':
        data_type = 'Respiration Rate_BPM'
    elif args.data_type == 'all':
        data_type = 'all'
    return data_type, data

# def readData(rawdata):
#     # Fill NaN Values in All Columns with Mean of that particular datatype row 
#     data = rawdata.fillna(rawdata.mean())
#     datanp = np.array(data)

#     column_names = np.array(['col_' + str(i) for i in range(16384)])
#     new_arr = np.insert(datanp, 0, column_names, axis=0)

#     new_linedata = new_arr[1,:]
#     new_arr2 = np.insert(new_arr, 1,new_linedata,axis=0)

#     data = pd.DataFrame(new_arr2)
#     # Assaigning new subject names
#     data.iloc[0,0] = 'Subject ID'
#     data.iloc[0,1] = 'Data Type'
#     data.iloc[0,2] = 'Class'
#     data.iloc[0,3] = 'Data'

#     data.set_axis(data.iloc[0], axis=1, inplace=True)  # set the first row as the column names
#     data.drop(data.index[0], inplace=True)  # remove the first row from the DataFrame
#     return data

def train_test_split(X,y,spf):
    limit = int(len(X)-spf)
    # samples from 0 to limit is considered for training
    # samples from limit to end is considerd for testing -> which exactly contains 6 subjects
    TrainData, TrainLabels = X[0:limit], y[0:limit]
    TestData, TestLabels = X[limit:],y[limit:]
    return TrainData, TrainLabels, TestData, TestLabels

def initialize_extra_features(data):
    length = len(data)
    data['mean'] = np.zeros(length)
    data['var'] = np.zeros(length)
    data['min'] = np.zeros(length)
    data['max'] = np.zeros(length)
    data['target'] = np.zeros(length)
    return data

def feature_extract(data):
    j = 0
    for subject in data['Sub ID'].unique():
        subject_data = data[data['Sub ID'] == subject]
        for i in range(8):
            features = np.array(subject_data.iloc[i][3:-1])
            # mean
            s_m_np = np.mean(features)
            data['mean'].iloc[i+j] = s_m_np
            # variance
            s_v_np = np.var(features)
            data['var'].iloc[i+j] = s_v_np
            # Minimum
            s_min_np = min(features)
            data['min'].iloc[i+j] = s_min_np
            # Maximum
            s_max_np = max(features)
            data['max'].iloc[i+j] = s_max_np
        j = j+8
    return data

def data_labelling(data):
    for i in range(len(data)):
        if data['Class'].iloc[i] == 'Pain':
            data['target'].iloc[i]=1
    return data

def extract_data(data_type, labeled_data):
    if data_type == 'all':
        return labeled_data
    else:
        return labeled_data[labeled_data['Data Type'] == data_type]

def extract(Extracted_data,data_type):
    X = Extracted_data[['mean','var','min','max']]
    y = Extracted_data[['target']]
    X = np.array(X, float)
    y = np.array(y, float)
    y = y.reshape((y.shape[0],))
    if data_type == 'all':
        # Fusion of all the datatypes of one subject ID with 16 features for the Pain/NoPain target
        Xnew = X.reshape(int(X.shape[0]/4),16)
        ynew = y.reshape(int(X.shape[0]/4),4)
        ynew = np.sum(ynew,axis=1)/4
        return Xnew,ynew
    else:
        return X,y